const { google } = require('googleapis');
const path = require('path');
const fs = require('fs');

// Load environment variables
require('dotenv').config();

// Google Drive configuration from environment variables
const GOOGLE_DRIVE_CONFIG = {
  CLIENT_EMAIL: process.env.GOOGLE_DRIVE_CLIENT_EMAIL,
  PRIVATE_KEY: process.env.GOOGLE_DRIVE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
  PROJECT_ID: process.env.GOOGLE_DRIVE_PROJECT_ID,
  CLIENT_ID: process.env.GOOGLE_DRIVE_CLIENT_ID
};

// Main folder ID from environment variables
const MAIN_FOLDER_ID = process.env.GOOGLE_DRIVE_MAIN_FOLDER_ID || '1OvhxktOCH7UtNz03Fd0gLbUZQmIZFaGY';

// Subfolder names and their known IDs (if they exist)
const FOLDER_NAMES = {
  SERVICE_IMAGES: 'our_services_section',
  ICON_IMAGES: 'our_services_icons',
  PRODUCT_IMAGES: 'our_services_product'
};

// Known folder IDs from environment variables
const KNOWN_FOLDER_IDS = {
  SERVICE_IMAGES: process.env.GOOGLE_DRIVE_SERVICE_IMAGES_FOLDER_ID || '1LVAz7zUHtaTLj7t3611XAmnYF96sVHCa',
  ICON_IMAGES: process.env.GOOGLE_DRIVE_ICON_IMAGES_FOLDER_ID || '1iZ9ZWSBSs8ibs2njoJT0DTbevN6XR8-K',
  PRODUCT_IMAGES: null // Will be determined or use main folder
};

class GoogleDriveService {
  constructor() {
    this.drive = null;
    this.folderIds = {};
    this.initialized = false;
  }

  async initialize() {
    try {
      // Validate required environment variables
      if (!GOOGLE_DRIVE_CONFIG.CLIENT_EMAIL || !GOOGLE_DRIVE_CONFIG.PRIVATE_KEY) {
        throw new Error('Missing required Google Drive credentials in environment variables. Please check GOOGLE_DRIVE_CLIENT_EMAIL and GOOGLE_DRIVE_PRIVATE_KEY.');
      }
      
      // Create JWT auth client using environment variables
      const auth = new google.auth.JWT(
        GOOGLE_DRIVE_CONFIG.CLIENT_EMAIL,
        null,
        GOOGLE_DRIVE_CONFIG.PRIVATE_KEY,
        ['https://www.googleapis.com/auth/drive']
      );

      // Initialize Google Drive API
      this.drive = google.drive({ version: 'v3', auth });
      
      // Ensure subfolders exist and get their IDs
      await this.ensureSubfoldersExist();
      
      this.initialized = true;
      console.log('Google Drive service initialized successfully');
    } catch (error) {
      console.error('Failed to initialize Google Drive service:', error);
      throw error;
    }
  }

  async ensureSubfoldersExist() {
    try {
      // First, try to use known folder IDs
      for (const [key, folderId] of Object.entries(KNOWN_FOLDER_IDS)) {
        if (folderId) {
          this.folderIds[key] = folderId;
          console.log(`Using known folder ID for ${FOLDER_NAMES[key]}: ${folderId}`);
        }
      }

      // Get existing folders in the main folder
      const response = await this.drive.files.list({
        q: `'${MAIN_FOLDER_ID}' in parents and mimeType='application/vnd.google-apps.folder'`,
        fields: 'files(id, name)'
      });

      const existingFolders = response.data.files || [];
      
      // Check and create each required subfolder
      for (const [key, folderName] of Object.entries(FOLDER_NAMES)) {
        // Skip if we already have a known folder ID
        if (this.folderIds[key]) {
          continue;
        }

        const existingFolder = existingFolders.find(folder => folder.name === folderName);
        
        if (existingFolder) {
          this.folderIds[key] = existingFolder.id;
          console.log(`Found existing folder: ${folderName} (ID: ${existingFolder.id})`);
        } else {
          // Try to create the folder, but handle permission errors gracefully
          try {
            const folderMetadata = {
              name: folderName,
              parents: [MAIN_FOLDER_ID],
              mimeType: 'application/vnd.google-apps.folder'
            };

            const folderResponse = await this.drive.files.create({
              resource: folderMetadata,
              fields: 'id'
            });

            this.folderIds[key] = folderResponse.data.id;
            console.log(`Created new folder: ${folderName} (ID: ${folderResponse.data.id})`);
          } catch (createError) {
            console.warn(`Cannot create folder ${folderName}, using main folder instead:`, createError.message);
            // Use main folder as fallback
            this.folderIds[key] = MAIN_FOLDER_ID;
          }
        }
      }

      // Ensure all folder types have an ID (fallback to main folder)
      for (const key of Object.keys(FOLDER_NAMES)) {
        if (!this.folderIds[key]) {
          console.warn(`No folder ID found for ${key}, using main folder`);
          this.folderIds[key] = MAIN_FOLDER_ID;
        }
      }

    } catch (error) {
      console.error('Error ensuring subfolders exist:', error);
      // Fallback: use main folder for all uploads
      console.warn('Using main folder for all uploads due to permission issues');
      for (const key of Object.keys(FOLDER_NAMES)) {
        this.folderIds[key] = MAIN_FOLDER_ID;
      }
    }
  }

  async uploadFile(fileBuffer, fileName, mimeType, folderType) {
    try {
      if (!this.initialized) {
        await this.initialize();
      }

      // Get the appropriate folder ID
      const folderId = this.folderIds[folderType];
      if (!folderId) {
        throw new Error(`Invalid folder type: ${folderType}`);
      }

      // Generate unique filename with timestamp
      const timestamp = Date.now();
      const fileExtension = path.extname(fileName);
      const baseName = path.basename(fileName, fileExtension);
      const uniqueFileName = `${baseName}_${timestamp}${fileExtension}`;

      // File metadata
      const fileMetadata = {
        name: uniqueFileName,
        parents: [folderId]
      };

      // Convert buffer to stream for Google Drive API
      const { Readable } = require('stream');
      const bufferStream = new Readable();
      bufferStream.push(fileBuffer);
      bufferStream.push(null); // End the stream

      // Upload the file
      const response = await this.drive.files.create({
        resource: fileMetadata,
        media: {
          mimeType: mimeType,
          body: bufferStream
        },
        fields: 'id, name, webViewLink'
      });

      const fileId = response.data.id;

      // Make the file publicly accessible
      await this.drive.permissions.create({
        fileId: fileId,
        resource: {
          role: 'reader',
          type: 'anyone'
        }
      });

      // Get the public download link - use the direct usercontent URL for better browser compatibility
      // This bypasses redirects and works better in img tags
      const publicLink = `https://drive.usercontent.google.com/download?id=${fileId}`;

      console.log(`File uploaded successfully: ${uniqueFileName} (ID: ${fileId})`);

      return {
        fileId: fileId,
        fileName: uniqueFileName,
        publicLink: publicLink,
        webViewLink: response.data.webViewLink
      };

    } catch (error) {
      console.error('Error uploading file to Google Drive:', error);
      throw error;
    }
  }

  async deleteFile(fileId) {
    try {
      if (!this.initialized) {
        await this.initialize();
      }

      await this.drive.files.delete({
        fileId: fileId
      });

      console.log(`File deleted successfully: ${fileId}`);
      return true;
    } catch (error) {
      console.error('Error deleting file from Google Drive:', error);
      throw error;
    }
  }

  // Helper method to get folder type based on upload context
  static getFolderType(uploadType) {
    switch (uploadType) {
      case 'service':
        return 'SERVICE_IMAGES';
      case 'icon':
        return 'ICON_IMAGES';
      case 'product':
        return 'PRODUCT_IMAGES';
      default:
        throw new Error(`Unknown upload type: ${uploadType}`);
    }
  }
}

// Create a singleton instance
const googleDriveService = new GoogleDriveService();

module.exports = googleDriveService; 