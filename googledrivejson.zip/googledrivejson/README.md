# Google Drive Service Account Credentials

This folder contains the service account credentials JSON file used for Google Drive API authentication.

## Contents

- `caretake-460910-86321148e3d9.json` - Service account credentials for the Google Drive API

## Usage

The service account credentials are used by the `googleDriveService.js` utility to authenticate with the Google Drive API.

## Security Note

The service account credentials JSON file contains sensitive information, including private keys. It should:

1. Never be committed to version control (add to .gitignore)
2. Be kept secure and only accessible to authorized personnel
3. Be rotated periodically according to your security policy

## Configuration

To use a different service account, replace the JSON file and update the environment variable:

```
GOOGLE_APPLICATION_CREDENTIALS=path/to/your-service-account-credentials.json
```

Or ensure your JSON file is named `caretake-460910-86321148e3d9.json` and placed in this directory. 