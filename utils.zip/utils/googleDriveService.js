/**
 * Google Drive Service
 * 
 * Provides functions for interacting with Google Drive API
 * Used for gallery image storage and management
 */

const { google } = require('googleapis');
const fs = require('fs');
const path = require('path');
const { Readable } = require('stream');

// Configuration
const SCOPES = ['https://www.googleapis.com/auth/drive'];
// Parent folder ID from the provided Google Drive link
const PARENT_FOLDER_ID = process.env.GOOGLE_DRIVE_PARENT_FOLDER_ID || '1tu-w7cYkEuHjcxi7BAOZjYyvd6SwZGrU';

// Shared Drive configuration to avoid storage quota issues
const SHARED_DRIVE_ID = process.env.GOOGLE_SHARED_DRIVE_ID || null;
const USE_SHARED_DRIVE = process.env.USE_SHARED_DRIVE === 'true' || false;

// Initialize the Google Drive API client
let driveClient = null;

/**
 * Initialize the Google Drive client using service account credentials
 * This should be called before using any other functions in this module
 */
const initializeDriveClient = () => {
  if (driveClient) return driveClient;
  
  try {
    // Check for required environment variables or use the JSON file directly
    const credentialsPath = process.env.GOOGLE_APPLICATION_CREDENTIALS || 
                          path.join(process.cwd(), 'googledrivejson', 'caretake-460910-86321148e3d9.json');
    
    console.log('Using Google Drive credentials from:', credentialsPath);
    
    // Check if credentials file exists
    if (!fs.existsSync(credentialsPath)) {
      throw new Error(`Google Drive credentials file not found at: ${credentialsPath}`);
    }
    
    // Create an auth client using the service account credentials
    const auth = new google.auth.GoogleAuth({
      keyFile: credentialsPath,
      scopes: SCOPES,
    });
    
    // Create the drive client
    driveClient = google.drive({ version: 'v3', auth });
    
    console.log('Google Drive client initialized successfully');
    return driveClient;
  } catch (error) {
    console.error('Error initializing Google Drive client:', error);
    throw error;
  }
};

/**
 * Find a folder by name in the parent folder
 * 
 * @param {string} folderName - Name of the folder to find
 * @param {string} parentFolderId - ID of the parent folder to search in
 * @returns {Promise<string|null>} - Folder ID if found, null otherwise
 */
const findFolder = async (folderName, parentFolderId = PARENT_FOLDER_ID) => {
  try {
    const drive = initializeDriveClient();
    
    const listParams = {
      q: `mimeType='application/vnd.google-apps.folder' and name='${folderName}' and '${parentFolderId}' in parents and trashed=false`,
      fields: 'files(id, name)',
      spaces: 'drive',
    };
    
    // Add shared drive support if configured
    if (USE_SHARED_DRIVE && SHARED_DRIVE_ID) {
      listParams.supportsAllDrives = true;
      listParams.includeItemsFromAllDrives = true;
    }
    
    const response = await drive.files.list(listParams);
    
    const folders = response.data.files;
    if (folders && folders.length > 0) {
      console.log(`Found folder: ${folderName} (${folders[0].id})`);
      return folders[0].id;
    }
    
    console.log(`Folder not found: ${folderName}`);
    return null;
  } catch (error) {
    console.error(`Error finding folder ${folderName}:`, error);
    throw error;
  }
};

/**
 * Create a new folder in Google Drive
 * 
 * @param {string} folderName - Name of the folder to create
 * @param {string} parentFolderId - ID of the parent folder
 * @returns {Promise<string>} - ID of the created folder
 */
const createFolder = async (folderName, parentFolderId = PARENT_FOLDER_ID) => {
  try {
    const drive = initializeDriveClient();
    
    const folderMetadata = {
      name: folderName,
      mimeType: 'application/vnd.google-apps.folder',
      parents: [parentFolderId],
    };
    
    const createParams = {
      resource: folderMetadata,
      fields: 'id',
    };
    
    // Add shared drive support if configured
    if (USE_SHARED_DRIVE && SHARED_DRIVE_ID) {
      createParams.supportsAllDrives = true;
    }
    
    const response = await drive.files.create(createParams);
    
    console.log(`Created folder: ${folderName} (${response.data.id})`);
    return response.data.id;
  } catch (error) {
    console.error(`Error creating folder ${folderName}:`, error);
    throw error;
  }
};

/**
 * Find or create a folder for a specific user
 * 
 * @param {string} personName - Name of the person/user
 * @returns {Promise<string>} - ID of the folder
 */
const findOrCreateUserGalleryFolder = async (personName) => {
  try {
    // Sanitize the person name for use in folder name
    const sanitizedName = personName.replace(/[^a-zA-Z0-9_]/g, '_');
    const folderName = `${sanitizedName}_GalleryImages`;
    
    // Try to find the folder
    const folderId = await findFolder(folderName);
    if (folderId) {
      return folderId;
    }
    
    // Create the folder if it doesn't exist
    return await createFolder(folderName);
  } catch (error) {
    console.error(`Error finding or creating user gallery folder for ${personName}:`, error);
    throw error;
  }
};

/**
 * Find or create a folder for vendor verification documents
 * 
 * @param {string} folderName - Name of the folder to create
 * @param {string} vendorId - ID of the vendor
 * @returns {Promise<string>} - ID of the folder
 */
const findOrCreateVendorFolder = async (folderName, vendorId) => {
  try {
    // Use the verification documents parent folder (provided in the requirements)
    const VERIFICATION_PARENT_FOLDER_ID = '138_pMybW5nDv-JLiveyoMAtleRa6-E8t';
    
    console.log(`Looking for vendor folder: ${folderName} in verification parent folder`);
    
    // Try to find the folder
    const folderId = await findFolder(folderName, VERIFICATION_PARENT_FOLDER_ID);
    if (folderId) {
      console.log(`Found existing vendor folder: ${folderId}`);
      return folderId;
    }
    
    // Create the folder if it doesn't exist
    console.log(`Creating new vendor folder: ${folderName}`);
    const newFolderId = await createFolder(folderName, VERIFICATION_PARENT_FOLDER_ID);
    console.log(`Created vendor folder with ID: ${newFolderId}`);
    return newFolderId;
  } catch (error) {
    console.error(`Error finding or creating vendor folder ${folderName}:`, error);
    throw error;
  }
};

/**
 * Upload a file to Google Drive
 * 
 * @param {string} filePath - Path to the file to upload
 * @param {string} fileName - Name to give the file in Google Drive
 * @param {string} mimeType - MIME type of the file
 * @param {string} folderId - ID of the folder to upload to
 * @returns {Promise<Object>} - Uploaded file metadata
 */
const uploadFile = async (filePath, fileName, mimeType, folderId) => {
  try {
    const drive = initializeDriveClient();
    
    const fileMetadata = {
      name: fileName,
      parents: [folderId],
    };
    
    const media = {
      mimeType: mimeType,
      body: fs.createReadStream(filePath),
    };
    
    // Configure request parameters for shared drive if applicable
    const requestParams = {
      resource: fileMetadata,
      media: media,
      fields: 'id,name,webContentLink,webViewLink',
    };
    
    // Add shared drive support if configured
    if (USE_SHARED_DRIVE && SHARED_DRIVE_ID) {
      requestParams.supportsAllDrives = true;
      requestParams.includeItemsFromAllDrives = true;
      console.log(`Using shared drive: ${SHARED_DRIVE_ID}`);
    }
    
    const response = await drive.files.create(requestParams);
    
    console.log(`Uploaded file: ${fileName} (${response.data.id})`);
    
    // Make the file publicly accessible
    await makeFilePublic(response.data.id);
    
    // Get the updated file with public links
    const getParams = {
      fileId: response.data.id,
      fields: 'id,name,webContentLink,webViewLink',
    };
    
    if (USE_SHARED_DRIVE && SHARED_DRIVE_ID) {
      getParams.supportsAllDrives = true;
    }
    
    const file = await drive.files.get(getParams);
    
    return file.data;
  } catch (error) {
    console.error(`Error uploading file ${fileName}:`, error);
    
    // If quota exceeded, provide helpful error message
    if (error.status === 403 && error.message.includes('storageQuotaExceeded')) {
      throw new Error('Google Drive storage quota exceeded. Please enable shared drive or clean up storage.');
    }
    
    throw error;
  }
};

/**
 * Upload a buffer directly to Google Drive
 * 
 * @param {Buffer} buffer - File buffer to upload
 * @param {string} fileName - Name to give the file in Google Drive
 * @param {string} mimeType - MIME type of the file
 * @param {string} folderId - ID of the folder to upload to
 * @returns {Promise<Object>} - Uploaded file metadata
 */
const uploadBufferToDrive = async (buffer, fileName, mimeType, folderId) => {
  try {
    const drive = initializeDriveClient();
    
    // Create a readable stream from the buffer
    const bufferStream = new Readable();
    bufferStream.push(buffer);
    bufferStream.push(null); // Signal the end of the stream
    
    const fileMetadata = {
      name: fileName,
      parents: [folderId],
    };
    
    const media = {
      mimeType: mimeType,
      body: bufferStream
    };
    
    // Configure request parameters for shared drive if applicable
    const requestParams = {
      resource: fileMetadata,
      media: media,
      fields: 'id,name,webContentLink,webViewLink',
    };
    
    // Add shared drive support if configured
    if (USE_SHARED_DRIVE && SHARED_DRIVE_ID) {
      requestParams.supportsAllDrives = true;
      requestParams.includeItemsFromAllDrives = true;
      console.log(`Using shared drive for buffer upload: ${SHARED_DRIVE_ID}`);
    }
    
    const response = await drive.files.create(requestParams);
    
    console.log(`Uploaded buffer: ${fileName} (${response.data.id})`);
    
    // Make the file publicly accessible
    await makeFilePublic(response.data.id);
    
    // Get the updated file with public links
    const file = await drive.files.get({
      fileId: response.data.id,
      fields: 'id,name,webContentLink,webViewLink',
    });
    
    return file.data;
  } catch (error) {
    console.error(`Error uploading buffer ${fileName}:`, error);
    throw error;
  }
};

/**
 * Make a file publicly accessible
 * 
 * @param {string} fileId - ID of the file to make public
 * @returns {Promise<void>}
 */
const makeFilePublic = async (fileId) => {
  try {
    const drive = initializeDriveClient();
    
    const permissionParams = {
      fileId: fileId,
      requestBody: {
        role: 'reader',
        type: 'anyone',
      },
    };
    
    // Add shared drive support if configured
    if (USE_SHARED_DRIVE && SHARED_DRIVE_ID) {
      permissionParams.supportsAllDrives = true;
    }
    
    await drive.permissions.create(permissionParams);
    
    console.log(`Made file public: ${fileId}`);
  } catch (error) {
    console.error(`Error making file public ${fileId}:`, error);
    throw error;
  }
};

/**
 * Upload a gallery image to the user's folder
 * 
 * @param {string|Buffer} imageInput - Path to the image file or Buffer containing image data
 * @param {string} personName - Name of the person/user
 * @param {Object} options - Additional options for processing
 * @returns {Promise<Object>} - Object containing file ID and public URL
 */
const uploadGalleryImage = async (imageInput, personName, options = {}) => {
  try {
    if (!personName) {
      throw new Error('Person name is required for folder creation');
    }
    
    console.log(`Processing gallery image for user: ${personName}`);
    
    // Get the user's gallery folder ID
    const folderId = await findOrCreateUserGalleryFolder(personName);
    console.log(`Using folder ID: ${folderId}`);
    
    // Check if imageInput is a string (file path) or Buffer
    let inputType = 'unknown';
    let tempFilePath = null;
    const webpOptions = {
      quality: options.quality || 80,
      resize: options.resize !== undefined ? options.resize : true,
      width: options.width || 1200
    };
    
    // Import the imageConverter utility for WebP conversion
    const imageConverter = require('./imageConverter');
    
    if (typeof imageInput === 'string') {
      inputType = 'file path';
      console.log(`Input is a file path: ${imageInput.substring(0, 50)}...`);
      
      // Check if file exists if it's a path
      if (!fs.existsSync(imageInput)) {
        throw new Error(`Input file does not exist: ${imageInput}`);
      }
      
      // Check if the file is already WebP format
      if (!imageInput.toLowerCase().endsWith('.webp')) {
        console.log('Converting image to WebP format...');
        // Convert the image to WebP format
        tempFilePath = await imageConverter.convertToWebP(imageInput, {
          outputDir: path.join(process.cwd(), 'temp'),
          ...webpOptions
        });
      } else {
        tempFilePath = imageInput;
      }
    } else if (Buffer.isBuffer(imageInput)) {
      inputType = 'buffer';
      console.log(`Input is a buffer of size: ${imageInput.length} bytes`);
      
      // Convert the buffer to WebP format
      console.log('Converting buffer to WebP format...');
      const result = await imageConverter.convertBufferToWebPFile(imageInput, {
        outputDir: path.join(process.cwd(), 'temp'),
        ...webpOptions
      });
      
      tempFilePath = result.path;
    } else {
      console.log(`Input type: ${typeof imageInput}, isBuffer: ${Buffer.isBuffer(imageInput)}`);
      throw new Error('Invalid image input type. Must be a file path or Buffer.');
    }
    
    // Generate a unique filename
    const timestamp = Date.now();
    const fileName = `gallery_image_${timestamp}.webp`;
    
    let uploadedFile;
    
    // Upload the WebP image to Google Drive
    console.log(`Uploading WebP image to Google Drive folder: ${folderId}`);
    try {
      uploadedFile = await uploadFile(
        tempFilePath,
        fileName,
        'image/webp', // Always use WebP mime type
        folderId
      );
      
      // If we created a temp file, delete it after upload
      if ((inputType === 'buffer' || tempFilePath !== imageInput) && tempFilePath) {
        try {
          fs.unlinkSync(tempFilePath);
          console.log(`Deleted temporary file: ${tempFilePath}`);
        } catch (unlinkError) {
          console.error(`Error deleting temporary file: ${unlinkError.message}`);
          // Don't throw here, just log the error
        }
      }
    } catch (uploadError) {
      // Clean up temp file if there was an error
      if ((inputType === 'buffer' || tempFilePath !== imageInput) && tempFilePath) {
        try {
          fs.unlinkSync(tempFilePath);
          console.log(`Deleted temporary file after error: ${tempFilePath}`);
        } catch (unlinkError) {
          console.error(`Error deleting temporary file: ${unlinkError.message}`);
        }
      }
      throw uploadError;
    }
    
    console.log(`Gallery image uploaded successfully to Drive as WebP: ${uploadedFile.id}`);
    
    // Return both the Drive file ID and the public URL
    return {
      fileId: uploadedFile.id,
      driveUrl: uploadedFile.webViewLink,
      publicUrl: uploadedFile.webContentLink
    };
  } catch (error) {
    console.error(`Error uploading gallery image for ${personName}:`, error);
    throw error;
  }
};

/**
 * Test function to create a test gallery folder
 * @returns {Promise<string>} - ID of the created folder
 */
const createTestGalleryFolder = async () => {
  try {
    const folderName = 'testgallery_GalleryImage';
    
    // Check if the folder already exists
    const existingFolderId = await findFolder(folderName);
    if (existingFolderId) {
      console.log(`Test gallery folder already exists: ${folderName} (${existingFolderId})`);
      return existingFolderId;
    }
    
    // Create the test folder
    return await createFolder(folderName);
  } catch (error) {
    console.error('Error creating test gallery folder:', error);
    throw error;
  }
};

/**
 * Delete a file from Google Drive
 * 
 * @param {string} fileId - ID of the file to delete
 * @returns {Promise<boolean>} - Success status
 */
const deleteFile = async (fileId) => {
  try {
    const drive = initializeDriveClient();
    
    await drive.files.delete({
      fileId: fileId
    });
    
    console.log(`Deleted file: ${fileId}`);
    return true;
  } catch (error) {
    console.error(`Error deleting file ${fileId}:`, error);
    throw error;
  }
};

/**
 * Initialize the Google Drive service (for compatibility with hybrid storage)
 */
const initialize = async () => {
  try {
    initializeDriveClient();
    return true;
  } catch (error) {
    console.error('Error initializing Google Drive service:', error);
    throw error;
  }
};

// Export functions
module.exports = {
  initializeDriveClient,
  findFolder,
  createFolder,
  findOrCreateUserGalleryFolder,
  findOrCreateVendorFolder,
  uploadFile,
  uploadBufferToDrive,
  makeFilePublic,
  uploadGalleryImage,
  createTestGalleryFolder,
  deleteFile,
  initialize
}; 